Nook cabinet CNC plans (starting values)
All units are inches.

PLYWOOD THICKNESS ASSUMED: 3/4 in sheet = 0.7188, 1/2 in sheet = 0.4688, 1/4 in sheet = 0.2188
Measure your sheets with calipers. If they differ by more than 0.01 in, rebuild the files on the web page (https://servanting.ca/share/nook/).

Each DXF is one 96 x 48 in sheet, viewed from above with the machined face up.
Layers: PROFILE_OUTSIDE (cut outside the line, with tabs), POCKET_<depth> (cut inside the line, depth in inches), DRILL_* (pilot marks, plunge holes and the latch stem mark), SHEET_BORDER and LABEL_NOCUT (never cut).
Apply dogbone relief to mortises, pockets and tab roots in your CAM software.
Test cut a dado and a door groove in scrap before cutting full sheets.
